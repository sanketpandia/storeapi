
'use strict';

let localConfig = {
    hostname: 'localhost',
    port: 8080
};

module.exports = localConfig;